# Cognifyz
Cognifyz Internship Tasks
